/*
The contents of this file are subject to the Common Public Attribution License 
Version 1.0 (the "License"); you may not use this file except in compliance with 
the License. You may obtain a copy of the License at 
http://www.projity.com/license . The License is based on the Mozilla Public 
License Version 1.1 but Sections 14 and 15 have been added to cover use of 
software over a computer network and provide for limited attribution for the 
Original Developer. In addition, Exhibit A has been modified to be consistent 
with Exhibit B.

Software distributed under the License is distributed on an "AS IS" basis, 
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for the 
specific language governing rights and limitations under the License. The 
Original Code is OpenProj. The Original Developer is the Initial Developer and 
is Projity, Inc. All portions of the code written by Projity are Copyright (c) 
2006, 2007. All Rights Reserved. Contributors Projity, Inc.

Alternatively, the contents of this file may be used under the terms of the 
Projity End-User License Agreeement (the Projity License), in which case the 
provisions of the Projity License are applicable instead of those above. If you 
wish to allow use of your version of this file only under the terms of the 
Projity License and not to allow others to use your version of this file under 
the CPAL, indicate your decision by deleting the provisions above and replace 
them with the notice and other provisions required by the Projity  License. If 
you do not delete the provisions above, a recipient may use your version of this 
file under either the CPAL or the Projity License.

[NOTE: The text of this license may differ slightly from the text of the notices 
in Exhibits A and B of the license at http://www.projity.com/license. You should 
use the latest text at http://www.projity.com/license for your modifications.
You may not remove this license text from the source files.]

Attribution Information: Attribution Copyright Notice: Copyright � 2006, 2007 
Projity, Inc. Attribution Phrase (not exceeding 10 words): Powered by OpenProj, 
an open source solution from Projity. Attribution URL: http://www.projity.com 
Graphic Image as provided in the Covered Code as file:  openproj_logo.png with 
alternatives listed on http://www.projity.com/logo

Display of Attribution Information is required in Larger Works which are defined 
in the CPAL as a work which combines Covered Code or portions thereof with code 
not governed by the terms of the CPAL. However, in addition to the other notice 
obligations, all copies of the Covered Code in Executable and Source Code form 
distributed must, as a form of attribution of the original author, include on 
each user interface screen the "OpenProj" logo visible to all users.  The 
OpenProj logo should be located horizontally aligned with the menu bar and left 
justified on the top left of the screen adjacent to the File menu.  The logo 
must be at least 100 x 25 pixels.  When users click on the "OpenProj" logo it 
must direct them back to http://www.projity.com.  
*/
package com.projity.configuration;

import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.commons.digester.Digester;

import com.projity.graphic.configuration.SpreadSheetFieldArray;
import com.projity.strings.Messages;

/**
 * Holds the definition of a report read in from the view config
 */
public class ReportDefinition implements NamedItem {
	
	private String name = null;
	private String id = null;
	private String file = null;
	private boolean timeBased = false;

	private int collectionType = 0;
	/**
	 * @return Returns the collectionType.
	 */
	public int getCollectionType() {
		return collectionType;
	}
	/**
	 * @param collectionType The collectionType to set.
	 */
	public void setCollectionType(int collectionType) {
		this.collectionType = collectionType;
	}
	private Object reportObject = null;
	private Hashtable reportColumnDefinitions = new Hashtable();
	/**
	 * @return Returns the columnsList.
	 */
	public ArrayList getColumnsList() {
		return columnsList;
	}
	private ArrayList columnsList = new ArrayList();

	
	/**
	 * @return Returns the timeBased.
	 */
	public boolean isTimeBased() {
		return timeBased;
	}
	/**
	 * @param timeBased The timeBased to set.
	 */
	public void setTimeBased(boolean timeBased) {
		this.timeBased = timeBased;
	}
	public static final String CATEGORY="Report";
	/* (non-Javadoc)
	 * @see com.projity.configuration.NamedItem#getName()
	 */
	public String getName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see com.projity.configuration.NamedItem#getCategory()
	 */
	public String getCategory() {
		return CATEGORY;
	}

	public final void setName(String name) {
		this.name = name;
	}
	public final String getId() {
		return id;
	}
	public final void setId(String id) {
		this.id = id;
		if (name == null)
			name = Messages.getString(id);
	}
    public static void addDigesterEvents(Digester digester){
		digester.addObjectCreate("*/reports/report", "com.projity.configuration.ReportDefinition");
		digester.addObjectCreate("*/reports/report/columns", "com.projity.configuration.ReportColumns");
	    digester.addSetProperties("*/reports/report");
	    digester.addSetProperties("*/reports/report/columns");
		digester.addSetNext("*/reports/report", "add", "com.projity.configuration.NamedItem");
		digester.addSetNext("*/reports/report/columns", "add", "com.projity.configuration.ReportColumns");
	    
	}
	
	public void add(ReportColumns columns) {
		columnsList.add(columns);
	}
	
	public String getMainSpreadsheetCategory() {
		if (columnsList.size() == 0)
			return null;
		return ((ReportColumns)columnsList.get(columnsList.size()-1)).getCategorySpreadSheet();
	}
	
	public SpreadSheetFieldArray getMainFieldArray() {
		if (columnsList.size() == 0)
			return null;
		return ((ReportColumns)columnsList.get(columnsList.size()-1)).getFieldArray();
		
	}
	public final Object getReportObject(ArrayList columns) {
		if (columns == null)
			return reportObject;
		return reportColumnDefinitions.get(columns);
	}
	public final void setReportObject(Object reportObject, ArrayList columns) {
		if (columns == null)
			this.reportObject = reportObject;
		else
			reportColumnDefinitions.put(columns,reportObject);
	}
	
	public String toString() {
		return name;
	}
	/**
	 * @return Returns the file.
	 */
	public String getFile() {
		return file;
	}
	/**
	 * @param file The file to set.
	 */
	public void setFile(String file) {
		this.file = file;
	}
}
