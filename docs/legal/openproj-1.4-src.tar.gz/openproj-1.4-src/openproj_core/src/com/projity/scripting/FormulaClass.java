/*
The contents of this file are subject to the Common Public Attribution License 
Version 1.0 (the "License"); you may not use this file except in compliance with 
the License. You may obtain a copy of the License at 
http://www.projity.com/license . The License is based on the Mozilla Public 
License Version 1.1 but Sections 14 and 15 have been added to cover use of 
software over a computer network and provide for limited attribution for the 
Original Developer. In addition, Exhibit A has been modified to be consistent 
with Exhibit B.

Software distributed under the License is distributed on an "AS IS" basis, 
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for the 
specific language governing rights and limitations under the License. The 
Original Code is OpenProj. The Original Developer is the Initial Developer and 
is Projity, Inc. All portions of the code written by Projity are Copyright (c) 
2006, 2007. All Rights Reserved. Contributors Projity, Inc.

Alternatively, the contents of this file may be used under the terms of the 
Projity End-User License Agreeement (the Projity License), in which case the 
provisions of the Projity License are applicable instead of those above. If you 
wish to allow use of your version of this file only under the terms of the 
Projity License and not to allow others to use your version of this file under 
the CPAL, indicate your decision by deleting the provisions above and replace 
them with the notice and other provisions required by the Projity  License. If 
you do not delete the provisions above, a recipient may use your version of this 
file under either the CPAL or the Projity License.

[NOTE: The text of this license may differ slightly from the text of the notices 
in Exhibits A and B of the license at http://www.projity.com/license. You should 
use the latest text at http://www.projity.com/license for your modifications.
You may not remove this license text from the source files.]

Attribution Information: Attribution Copyright Notice: Copyright � 2006, 2007 
Projity, Inc. Attribution Phrase (not exceeding 10 words): Powered by OpenProj, 
an open source solution from Projity. Attribution URL: http://www.projity.com 
Graphic Image as provided in the Covered Code as file:  openproj_logo.png with 
alternatives listed on http://www.projity.com/logo

Display of Attribution Information is required in Larger Works which are defined 
in the CPAL as a work which combines Covered Code or portions thereof with code 
not governed by the terms of the CPAL. However, in addition to the other notice 
obligations, all copies of the Covered Code in Executable and Source Code form 
distributed must, as a form of attribution of the original author, include on 
each user interface screen the "OpenProj" logo visible to all users.  The 
OpenProj logo should be located horizontally aligned with the menu bar and left 
justified on the top left of the screen adjacent to the File menu.  The logo 
must be at least 100 x 25 pixels.  When users click on the "OpenProj" logo it 
must direct them back to http://www.projity.com.  
*/
package com.projity.scripting;

import groovy.lang.GroovyClassLoader;
import groovy.lang.GroovyObject;

import java.util.ArrayList;
import java.util.Iterator;

import com.projity.field.InvalidFormulaException;

public class FormulaClass {
	ArrayList formulas = new ArrayList();
	String className;
	private boolean init = false;
	private static final String imports="";
	private Class groovyClass= null;
	private GroovyObject groovyObject = null;

	public FormulaClass(String className) {
		this.className = className;
	}
	
	void add(ScriptedFormula formula) {
		formulas.add(formula);
		formula.setFormulaClass(this);

	}
	
	private Exception compileException = null;
	public synchronized void compile() {
		if (groovyClass == null) {
			Runnable r = new Runnable(){
				public void run() {
//					long x = System.currentTimeMillis();
					String classText = buildClassText();
					GroovyClassLoader loader = new GroovyClassLoader(getClass().getClassLoader());
//					GroovyClassLoader loader = new GroovyClassLoader(ClassLoaderUtils.getLocalClassLoader());
					try {
						groovyClass = loader.parseClass(classText); //TODO this his horribly slow (~500ms)  Can we parse all at once or can we do this lazily or initialize in another thread?
						groovyObject = (GroovyObject) groovyClass.newInstance(); // this would be ideally done by a factory
					} catch (Exception e) {
						compileException = e;
						System.out.println(e);
					}
//					System.out.println("compiled class " + className + " in " + (System.currentTimeMillis()-x) + "ms");
				}
			};
			r.run();
		}
	}
	
	
	private String buildClassText() {
		StringBuffer text = new StringBuffer();
		text.append(imports);
		text.append("class " + className + " {");
		
		Iterator i = formulas.iterator();
		while (i.hasNext()) {
			ScriptedFormula formula = (ScriptedFormula)i.next();
			text.append("\n\tObject " + formula.getFormulaName() + "(Object " + formula.getVariableName() + ") {");
			text.append("\n\t\treturn " + formula.getText()+ ";\n\t}");
		}
		text.append("\n}"); // end of class body
		return text.toString();
	}
	
	Object args[] = new Object[1];
	public Object evaluate(String method, Object object) throws InvalidFormulaException {
		// lets call some method on an instance
		try {
			if (groovyClass == null)
				compile();
			args[0] = object;
			return groovyObject.invokeMethod(method, args);		 //TODO eventually cache the Method 
		} catch (Exception e) {
			e.printStackTrace();
			throw new InvalidFormulaException(e);
		}
	}	
}
